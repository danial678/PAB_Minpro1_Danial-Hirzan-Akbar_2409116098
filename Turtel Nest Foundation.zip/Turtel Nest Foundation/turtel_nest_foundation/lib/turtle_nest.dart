class TurtleNest {
  String id;
  String location;
  String species;
  String eggCount;
  String condition;
  String date;

  TurtleNest({
    required this.id,
    required this.location,
    required this.species,
    required this.eggCount,
    required this.condition,
    required this.date,
  });
}
