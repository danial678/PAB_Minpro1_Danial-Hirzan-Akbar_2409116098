import 'package:flutter/material.dart';
import 'turtle_nest.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Konservasi Penyu',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: const HomePage(),
    );
  }
}

// ==========================================
// HALAMAN UTAMA - DAFTAR SARANG
// ==========================================
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // List untuk menyimpan data sarang
  List<TurtleNest> nests = [];

  // Controller untuk form input
  final locationCtrl = TextEditingController();
  final speciesCtrl = TextEditingController();
  final eggCountCtrl = TextEditingController();
  final conditionCtrl = TextEditingController();
  final dateCtrl = TextEditingController();

  // Fungsi TAMBAH data
  void addNest() {
    // Validasi sederhana
    if (locationCtrl.text.isEmpty ||
        speciesCtrl.text.isEmpty ||
        eggCountCtrl.text.isEmpty ||
        conditionCtrl.text.isEmpty ||
        dateCtrl.text.isEmpty) {
      showMessage('Semua field harus diisi!', Colors.red);
      return;
    }

    setState(() {
      nests.add(TurtleNest(
        id: DateTime.now().toString(), // ID sederhana dari timestamp
        location: locationCtrl.text,
        species: speciesCtrl.text,
        eggCount: eggCountCtrl.text,
        condition: conditionCtrl.text,
        date: dateCtrl.text,
      ));
    });

    // Bersihkan form
    locationCtrl.clear();
    speciesCtrl.clear();
    eggCountCtrl.clear();
    conditionCtrl.clear();
    dateCtrl.clear();

    Navigator.pop(context); // Tutup dialog
    showMessage('Data berhasil ditambahkan!', Colors.green);
  }

  // Fungsi HAPUS data
  void deleteNest(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Data?'),
        content: const Text('Yakin ingin menghapus data ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                nests.removeAt(index);
              });
              Navigator.pop(context);
              showMessage('Data dihapus!', Colors.red);
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  // Fungsi EDIT data
  void editNest(int index) {
    // Isi form dengan data lama
    locationCtrl.text = nests[index].location;
    speciesCtrl.text = nests[index].species;
    eggCountCtrl.text = nests[index].eggCount;
    conditionCtrl.text = nests[index].condition;
    dateCtrl.text = nests[index].date;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Data Sarang'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: locationCtrl,
                decoration: const InputDecoration(labelText: 'Lokasi'),
              ),
              TextField(
                controller: speciesCtrl,
                decoration: const InputDecoration(labelText: 'Jenis Penyu'),
              ),
              TextField(
                controller: eggCountCtrl,
                decoration: const InputDecoration(labelText: 'Jumlah Telur'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: conditionCtrl,
                decoration: const InputDecoration(labelText: 'Kondisi'),
              ),
              TextField(
                controller: dateCtrl,
                decoration: const InputDecoration(labelText: 'Tanggal'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              // Bersihkan form
              locationCtrl.clear();
              speciesCtrl.clear();
              eggCountCtrl.clear();
              conditionCtrl.clear();
              dateCtrl.clear();
              Navigator.pop(context);
            },
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              // Validasi
              if (locationCtrl.text.isEmpty ||
                  speciesCtrl.text.isEmpty ||
                  eggCountCtrl.text.isEmpty) {
                showMessage('Field wajib diisi!', Colors.red);
                return;
              }

              setState(() {
                nests[index] = TurtleNest(
                  id: nests[index].id,
                  location: locationCtrl.text,
                  species: speciesCtrl.text,
                  eggCount: eggCountCtrl.text,
                  condition: conditionCtrl.text,
                  date: dateCtrl.text,
                );
              });

              // Bersihkan form
              locationCtrl.clear();
              speciesCtrl.clear();
              eggCountCtrl.clear();
              conditionCtrl.clear();
              dateCtrl.clear();

              Navigator.pop(context);
              showMessage('Data berhasil diupdate!', Colors.green);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  // Fungsi tampilkan pesan
  void showMessage(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
      ),
    );
  }

  // Dialog tambah data baru
  void showAddDialog() {
    // Pastikan form bersih
    locationCtrl.clear();
    speciesCtrl.clear();
    eggCountCtrl.clear();
    conditionCtrl.clear();
    dateCtrl.clear();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tambah Data Sarang'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: locationCtrl,
                decoration: const InputDecoration(
                  labelText: 'Lokasi Sarang *',
                  hintText: 'Contoh: Pantai Sukamade',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: speciesCtrl,
                decoration: const InputDecoration(
                  labelText: 'Jenis Penyu *',
                  hintText: 'Contoh: Penyu Hijau',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: eggCountCtrl,
                decoration: const InputDecoration(
                  labelText: 'Jumlah Telur *',
                  hintText: 'Contoh: 120',
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 10),
              TextField(
                controller: conditionCtrl,
                decoration: const InputDecoration(
                  labelText: 'Kondisi *',
                  hintText: 'Baik/Rusak/Dicuri',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: dateCtrl,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Ditemukan *',
                  hintText: 'DD/MM/YYYY',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: addNest,
            child: const Text('Tambah'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🐢 Konservasi Penyu'),
        centerTitle: true,
      ),
      body: nests.isEmpty
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.beach_access, size: 80, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'Belum ada data sarang',
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                  Text(
                    'Tap + untuk menambahkan',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              itemCount: nests.length,
              itemBuilder: (context, index) {
                final nest = nests[index];
                return Card(
                  margin: const EdgeInsets.all(8),
                  child: ListTile(
                    leading: const Icon(Icons.pets, color: Colors.teal, size: 40),
                    title: Text(
                      nest.location,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      '${nest.species} • ${nest.eggCount} telur • ${nest.condition}\n${nest.date}',
                    ),
                    isThreeLine: true,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Tombol EDIT
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.blue),
                          onPressed: () => editNest(index),
                        ),
                        // Tombol DELETE
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteNest(index),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: showAddDialog,
        child: const Icon(Icons.add),
      ),
    );
  }

  @override
  void dispose() {
    // Bersihkan controller
    locationCtrl.dispose();
    speciesCtrl.dispose();
    eggCountCtrl.dispose();
    conditionCtrl.dispose();
    dateCtrl.dispose();
    super.dispose();
  }
}