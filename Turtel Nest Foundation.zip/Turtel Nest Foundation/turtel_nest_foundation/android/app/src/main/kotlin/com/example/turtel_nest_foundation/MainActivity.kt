package com.example.turtel_nest_foundation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
